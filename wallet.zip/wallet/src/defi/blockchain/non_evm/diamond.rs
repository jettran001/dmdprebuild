//! Module cho Diamond blockchain provider
//!
//! Module này cung cấp các chức năng để tương tác với mạng Diamond,
//! bao gồm các chức năng như truy vấn số dư, gửi giao dịch, và quản lý tài khoản.
//!
//! ## Ví dụ:
//! ```rust
//! use wallet::defi::blockchain::non_evm::diamond::{DiamondProvider, DiamondConfig};
//! use wallet::defi::blockchain::ChainId;
//!
//! #[tokio::main]
//! async fn main() {
//!     let config = DiamondConfig::new(ChainId::DiamondMainnet);
//!     let provider = DiamondProvider::new(config).unwrap();
//!
//!     let balance = provider.get_balance("DdkNKDGXR7FkH3mZAwxMrhxJAnoEzQ9qWL").await.unwrap();
//!     println!("Balance: {}", balance);
//! }
//! ```

use std::sync::Arc;
use std::time::Duration;
use std::collections::HashMap;
use once_cell::sync::Lazy;
use tokio::sync::RwLock;
use anyhow::Result;
use async_trait::async_trait;
use serde::{Serialize, Deserialize};
use ethers::types::{U256, H256};
use tracing::{debug, info, warn, error};
use reqwest::{Client, ClientBuilder};
use serde_json::{json, Value};
use regex::Regex;

use crate::defi::blockchain::{
    BlockchainProvider, BlockchainType, BlockchainConfig
};
use crate::defi::chain::ChainId;
use crate::defi::error::DefiError;
use crate::defi::constants::BLOCKCHAIN_TIMEOUT;

/// Cấu hình cho Diamond Provider
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiamondConfig {
    /// Chain ID
    pub chain_id: ChainId,
    /// RPC URL
    pub rpc_url: String,
    /// Explorer URL
    pub explorer_url: String,
    /// Timeout (ms)
    pub timeout_ms: u64,
    /// Số lần retry tối đa
    pub max_retries: u32,
}

impl DiamondConfig {
    /// Tạo cấu hình mới với các giá trị mặc định
    pub fn new(chain_id: ChainId) -> Self {
        let (rpc_url, explorer_url) = match chain_id {
            ChainId::DiamondMainnet => (
                "https://mainnet-rpc.diamondprotocol.co",
                "https://explorer.diamondprotocol.co"
            ),
            ChainId::DiamondTestnet => (
                "https://testnet-rpc.diamondprotocol.co",
                "https://testnet-explorer.diamondprotocol.co"
            ),
            _ => panic!("Invalid Diamond chain ID")
        };

        Self {
            chain_id,
            rpc_url: rpc_url.to_string(),
            explorer_url: explorer_url.to_string(),
            timeout_ms: BLOCKCHAIN_TIMEOUT,
            max_retries: 3,
        }
    }

    /// Thiết lập RPC URL
    pub fn with_rpc_url(mut self, rpc_url: &str) -> Self {
        self.rpc_url = rpc_url.to_string();
        self
    }

    /// Thiết lập Explorer URL
    pub fn with_explorer_url(mut self, explorer_url: &str) -> Self {
        self.explorer_url = explorer_url.to_string();
        self
    }

    /// Thiết lập timeout
    pub fn with_timeout(mut self, timeout_ms: u64) -> Self {
        self.timeout_ms = timeout_ms;
        self
    }

    /// Thiết lập số lần retry tối đa
    pub fn with_max_retries(mut self, max_retries: u32) -> Self {
        self.max_retries = max_retries;
        self
    }
}

/// Định nghĩa Diamond Provider
static DIAMOND_PROVIDER_CACHE: Lazy<RwLock<HashMap<ChainId, Arc<DiamondProvider>>>> = Lazy::new(|| {
    RwLock::new(HashMap::new())
});

/// Loại token của Diamond blockchain
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum DiamondTokenType {
    /// Native token của Diamond blockchain
    Native,
    /// Token chuẩn DRC-20 (tương tự ERC-20)
    DRC20,
    /// Token chuẩn DRC-721 (tương tự ERC-721, NFT)
    DRC721,
    /// Token chuẩn DRC-1155 (tương tự ERC-1155, Multi-token)
    DRC1155,
}

/// Thông tin token Diamond
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiamondTokenInfo {
    /// ID của token
    pub id: String,
    /// Tên token
    pub name: String,
    /// Ký hiệu token
    pub symbol: String,
    /// Số thập phân (decimals)
    pub decimals: u8,
    /// Tổng cung
    pub total_supply: U256,
    /// Loại token
    pub token_type: DiamondTokenType,
    /// Địa chỉ của contract token 
    pub contract_address: String,
}

/// Diamond blockchain provider
pub struct DiamondProvider {
    /// Cấu hình
    pub config: DiamondConfig,
    /// HTTP client
    client: Client,
}

impl DiamondProvider {
    /// Tạo provider mới
    pub fn new(config: DiamondConfig) -> Result<Self, DefiError> {
        let client = ClientBuilder::new()
            .timeout(Duration::from_millis(config.timeout_ms))
            .build()
            .map_err(|e| DefiError::ProviderError(format!("Failed to create Diamond client: {}", e)))?;

        Ok(Self {
            config,
            client,
        })
    }

    /// Lấy Diamond provider từ cache hoặc tạo mới
    pub async fn get_provider(chain_id: ChainId) -> Result<Arc<DiamondProvider>, DefiError> {
        // Kiểm tra chain ID có phải là Diamond chain không
        match chain_id {
            ChainId::DiamondMainnet | ChainId::DiamondTestnet => {},
            _ => return Err(DefiError::ChainNotSupported(format!(
                "Expected Diamond chains, got {:?}", 
                chain_id
            ))),
        }

        // Thử lấy từ cache trước
        {
            let cache = DIAMOND_PROVIDER_CACHE.read().await;
            if let Some(provider) = cache.get(&chain_id) {
                return Ok(provider.clone());
            }
        }

        // Nếu không có trong cache, tạo mới
        let config = DiamondConfig::new(chain_id);
        let provider = DiamondProvider::new(config)?;
        let provider = Arc::new(provider);

        // Lưu vào cache
        {
            let mut cache = DIAMOND_PROVIDER_CACHE.write().await;
            cache.insert(chain_id, provider.clone());
        }

        Ok(provider)
    }

    /// Gọi JSON-RPC API
    pub async fn call_rpc<T>(&self, method: &str, params: Value) -> Result<T, DefiError> 
    where
        T: for<'de> Deserialize<'de>,
    {
        let request_body = json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": params
        });

        let mut retry_count = 0;
        let max_retries = self.config.max_retries;

        loop {
            let response = match self.client.post(&self.config.rpc_url)
                .json(&request_body)
                .send()
                .await {
                    Ok(res) => res,
                    Err(e) => {
                        // Xử lý lỗi kết nối mạng
                        retry_count += 1;
                        if retry_count > max_retries {
                            return Err(DefiError::ProviderError(
                                format!("Failed to connect to Diamond network after {} retries: {}", max_retries, e)
                            ));
                        }
                        
                        // Log lỗi và chờ một thời gian trước khi thử lại
                        warn!(
                            method = %method,
                            error = %e,
                            retry = retry_count,
                            "Kết nối tới Diamond network thất bại, đang thử lại..."
                        );
                        
                        tokio::time::sleep(Duration::from_millis(500 * retry_count as u64)).await;
                        continue;
                    }
                };

            if response.status().is_success() {
                let json_response: Value = match response.json().await {
                    Ok(json) => json,
                    Err(e) => {
                        return Err(DefiError::ProviderError(
                            format!("Failed to parse Diamond RPC response: {}", e)
                        ));
                    }
                };

                if let Some(error) = json_response.get("error") {
                    let error_message = error["message"].as_str().unwrap_or("Unknown error");
                    let error_code = error["code"].as_i64().unwrap_or(0);
                    return Err(DefiError::ProviderError(
                        format!("Diamond RPC error (code {}): {}", error_code, error_message)
                    ));
                }

                if let Some(result) = json_response.get("result") {
                    match serde_json::from_value(result.clone()) {
                        Ok(data) => return Ok(data),
                        Err(e) => {
                            return Err(DefiError::ProviderError(
                                format!("Failed to deserialize Diamond RPC result: {}", e)
                            ));
                        }
                    }
                }

                return Err(DefiError::ProviderError("Diamond RPC response has no result field".to_string()));
            } else {
                // Xử lý lỗi HTTP status
                let status = response.status();
                let error_text = match response.text().await {
                    Ok(text) => text,
                    Err(_) => "Unknown error".to_string(),
                };
                
                retry_count += 1;
                if retry_count > max_retries {
                    return Err(DefiError::ProviderError(
                        format!("Diamond RPC HTTP error ({}): {}", status, error_text)
                    ));
                }
                
                warn!(
                    method = %method,
                    status = %status,
                    error = %error_text,
                    retry = retry_count,
                    "Diamond RPC trả về lỗi HTTP, đang thử lại..."
                );
                
                tokio::time::sleep(Duration::from_millis(500 * retry_count as u64)).await;
            }
        }
    }

    /// Kiểm tra địa chỉ Diamond có hợp lệ không
    pub fn validate_address(&self, address: &str) -> bool {
        if address.is_empty() {
            return false;
        }

        // Kiểm tra độ dài
        if address.len() < 32 || address.len() > 36 {
            return false;
        }

        // Kiểm tra tiền tố D
        if !address.starts_with('D') {
            return false;
        }

        // Kiểm tra các ký tự hợp lệ (base58)
        let base58_chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
        for c in address.chars() {
            if !base58_chars.contains(c) {
                return false;
            }
        }

        // Kiểm tra checksum (nếu cần thiết cho định dạng địa chỉ Diamond)
        // Đối với các blockchain như Bitcoin và nhiều blockchain khác,
        // địa chỉ base58 thường có embedded checksum
        // TODO: Implement Diamond-specific checksum validation
        
        // Kiểm tra format theo chuẩn Diamond
        let regex = Regex::new(r"^D[1-9A-HJ-NP-Za-km-z]{31,35}$").unwrap();
        regex.is_match(address)
    }

    /// Chuyển đổi từ địa chỉ Base58 sang Hex
    pub fn address_base58_to_hex(&self, address: &str) -> Result<String, DefiError> {
        if !self.validate_address(address) {
            return Err(DefiError::ProviderError(format!("Invalid Diamond address: {}", address)));
        }
        
        // TODO: Implement proper Base58 to Hex conversion for Diamond addresses
        // Đây là một triển khai giả định
        // Trong thực tế, cần sử dụng thư viện Base58 chuyên dụng
        
        // Đối với mục đích hiện tại, trả về một giá trị hex tạm thời
        Ok(format!("0x{}", address.as_bytes().iter().map(|b| format!("{:02x}", b)).collect::<String>()))
    }
    
    /// Chuyển đổi từ địa chỉ Hex sang Base58
    pub fn address_hex_to_base58(&self, hex: &str) -> Result<String, DefiError> {
        if !hex.starts_with("0x") {
            return Err(DefiError::ProviderError(format!("Invalid hex format: {}", hex)));
        }
        
        // TODO: Implement proper Hex to Base58 conversion for Diamond addresses
        // Đây là một triển khai giả định
        // Trong thực tế, cần sử dụng thư viện Base58 chuyên dụng
        
        // Trả về một địa chỉ Base58 tạm thời
        let sample_address = "DdkNKDGXR7FkH3mZAwxMrhxJAnoEzQ9qWL";
        Ok(sample_address.to_string())
    }

    /// Lấy số block hiện tại
    pub async fn get_block_height(&self) -> Result<u64, DefiError> {
        #[derive(Deserialize)]
        struct BlockHeightResult {
            height: String, // Có thể là string hoặc number tùy thuộc vào API
        }

        let result: BlockHeightResult = self.call_rpc("blockchain.getBlockHeight", json!([])).await?;
        result.height.parse::<u64>().map_err(|e| 
            DefiError::ProviderError(format!("Failed to parse block height: {}", e))
        )
    }

    /// Lấy thông tin block
    pub async fn get_block(&self, height: u64) -> Result<Value, DefiError> {
        self.call_rpc("blockchain.getBlock", json!([height])).await
    }

    /// Lấy thông tin giao dịch
    pub async fn get_transaction(&self, tx_hash: &str) -> Result<Value, DefiError> {
        self.call_rpc("blockchain.getTransaction", json!([tx_hash])).await
    }

    /// Lấy trạng thái giao dịch
    pub async fn get_transaction_status(&self, tx_hash: &str) -> Result<String, DefiError> {
        #[derive(Deserialize)]
        struct TxStatusResult {
            status: String,
        }

        let result: TxStatusResult = self.call_rpc("blockchain.getTransactionStatus", json!([tx_hash])).await?;
        Ok(result.status)
    }

    /// Lấy số dư tài khoản
    pub async fn get_account_balance(&self, address: &str) -> Result<U256, DefiError> {
        if !self.validate_address(address) {
            return Err(DefiError::ProviderError(format!("Invalid Diamond address: {}", address)));
        }

        #[derive(Deserialize)]
        struct BalanceResult {
            balance: String, // Có thể là string hoặc number tùy thuộc vào API
        }

        let result: BalanceResult = self.call_rpc("accounts.getBalance", json!([address])).await?;
        
        // Chuyển đổi string sang U256
        let balance = U256::from_dec_str(&result.balance).map_err(|e| 
            DefiError::ProviderError(format!("Failed to parse Diamond balance: {}", e))
        )?;
        
        Ok(balance)
    }

    /// Lấy số dư token
    pub async fn get_token_balance(&self, address: &str, token_id: &str) -> Result<U256, DefiError> {
        if !self.validate_address(address) {
            return Err(DefiError::ProviderError(format!("Invalid Diamond address: {}", address)));
        }

        #[derive(Deserialize)]
        struct TokenBalanceResult {
            balance: String,
        }

        let result: TokenBalanceResult = self.call_rpc(
            "tokens.getBalance", 
            json!([address, token_id])
        ).await?;
        
        let balance = U256::from_dec_str(&result.balance).map_err(|e| 
            DefiError::ProviderError(format!("Failed to parse Diamond token balance: {}", e))
        )?;
        
        Ok(balance)
    }

    /// Broadcast giao dịch đã ký
    pub async fn broadcast_transaction(&self, signed_tx: &str) -> Result<String, DefiError> {
        #[derive(Deserialize)]
        struct BroadcastResult {
            tx_hash: String,
        }

        let result: BroadcastResult = self.call_rpc(
            "transactions.broadcast", 
            json!([signed_tx])
        ).await?;
        
        Ok(result.tx_hash)
    }

    /// Lấy thông tin về token
    pub async fn get_token_info(&self, token_id: &str) -> Result<DiamondTokenInfo, DefiError> {
        #[derive(Deserialize)]
        struct TokenInfoResult {
            id: String,
            name: String,
            symbol: String,
            decimals: u8,
            total_supply: String,
            token_type: String,
            contract_address: String,
        }

        let result: TokenInfoResult = self.call_rpc(
            "tokens.getInfo", 
            json!([token_id])
        ).await?;
        
        let token_type = match result.token_type.as_str() {
            "native" => DiamondTokenType::Native,
            "drc20" => DiamondTokenType::DRC20,
            "drc721" => DiamondTokenType::DRC721,
            "drc1155" => DiamondTokenType::DRC1155,
            _ => return Err(DefiError::ProviderError(format!("Unknown token type: {}", result.token_type))),
        };
        
        let total_supply = U256::from_dec_str(&result.total_supply).map_err(|e| 
            DefiError::ProviderError(format!("Failed to parse token total supply: {}", e))
        )?;
        
        Ok(DiamondTokenInfo {
            id: result.id,
            name: result.name,
            symbol: result.symbol,
            decimals: result.decimals,
            total_supply,
            token_type,
            contract_address: result.contract_address,
        })
    }
    
    /// Lấy số dư token DRC-20
    pub async fn get_drc20_balance(&self, address: &str, token_id: &str) -> Result<U256, DefiError> {
        if !self.validate_address(address) {
            return Err(DefiError::ProviderError(format!("Invalid Diamond address: {}", address)));
        }

        #[derive(Deserialize)]
        struct TokenBalanceResult {
            balance: String,
        }

        let result: TokenBalanceResult = self.call_rpc(
            "tokens.getDRC20Balance", 
            json!([address, token_id])
        ).await?;
        
        let balance = U256::from_dec_str(&result.balance).map_err(|e| 
            DefiError::ProviderError(format!("Failed to parse DRC-20 token balance: {}", e))
        )?;
        
        Ok(balance)
    }
    
    /// Kiểm tra xem một địa chỉ có sở hữu NFT không
    pub async fn owns_drc721_token(&self, address: &str, token_id: &str, nft_id: &str) -> Result<bool, DefiError> {
        if !self.validate_address(address) {
            return Err(DefiError::ProviderError(format!("Invalid Diamond address: {}", address)));
        }

        #[derive(Deserialize)]
        struct OwnerResult {
            owner: String,
        }

        let result: OwnerResult = self.call_rpc(
            "tokens.getDRC721Owner", 
            json!([token_id, nft_id])
        ).await?;
        
        Ok(result.owner == address)
    }
    
    /// Lấy số dư token DRC-1155
    pub async fn get_drc1155_balance(&self, address: &str, token_id: &str, item_id: &str) -> Result<U256, DefiError> {
        if !self.validate_address(address) {
            return Err(DefiError::ProviderError(format!("Invalid Diamond address: {}", address)));
        }

        #[derive(Deserialize)]
        struct TokenBalanceResult {
            balance: String,
        }

        let result: TokenBalanceResult = self.call_rpc(
            "tokens.getDRC1155Balance", 
            json!([address, token_id, item_id])
        ).await?;
        
        let balance = U256::from_dec_str(&result.balance).map_err(|e| 
            DefiError::ProviderError(format!("Failed to parse DRC-1155 token balance: {}", e))
        )?;
        
        Ok(balance)
    }
}

#[async_trait]
impl BlockchainProvider for DiamondProvider {
    fn chain_id(&self) -> ChainId {
        self.config.chain_id
    }
    
    fn blockchain_type(&self) -> BlockchainType {
        BlockchainType::Diamond
    }
    
    async fn is_connected(&self) -> Result<bool, DefiError> {
        // Kiểm tra kết nối bằng cách lấy block hiện tại
        match self.get_block_height().await {
            Ok(_) => Ok(true),
            Err(_) => Ok(false),
        }
    }
    
    async fn get_block_number(&self) -> Result<u64, DefiError> {
        self.get_block_height().await
    }
    
    async fn get_balance(&self, address: &str) -> Result<U256, DefiError> {
        self.get_account_balance(address).await
    }
}

/// Tạo Diamond provider
pub async fn create_diamond_provider(config: BlockchainConfig) -> Result<Box<dyn BlockchainProvider>, DefiError> {
    // Kiểm tra chain ID có phải là Diamond chain không
    match config.chain_id {
        ChainId::DiamondMainnet | ChainId::DiamondTestnet => {},
        _ => return Err(DefiError::ChainNotSupported(format!(
            "Expected Diamond chains, got {:?}", 
            config.chain_id
        ))),
    }
    
    // Tạo cấu hình mặc định cho chain
    let mut diamond_config = DiamondConfig::new(config.chain_id);
    
    // Cập nhật RPC URL nếu được cung cấp
    if !config.rpc_url.is_empty() {
        diamond_config = diamond_config.with_rpc_url(&config.rpc_url);
    }
    
    // Cập nhật các tham số khác
    diamond_config = diamond_config
        .with_timeout(config.timeout_ms)
        .with_max_retries(config.max_retries);
    
    let provider = DiamondProvider::new(diamond_config)?;
    Ok(Box::new(provider))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_diamond_config() {
        let config = DiamondConfig::new(ChainId::DiamondMainnet);
        assert_eq!(config.chain_id, ChainId::DiamondMainnet);
        assert_eq!(config.rpc_url, "https://mainnet-rpc.diamondprotocol.co");
        
        let config = config.with_timeout(5000);
        assert_eq!(config.timeout_ms, 5000);
        
        let config = config.with_max_retries(5);
        assert_eq!(config.max_retries, 5);
    }

    #[test]
    fn test_validate_address() {
        let config = DiamondConfig::new(ChainId::DiamondMainnet);
        let provider = DiamondProvider::new(config).unwrap();
        
        // Địa chỉ hợp lệ (giả định)
        assert!(provider.validate_address("DdkNKDGXR7FkH3mZAwxMrhxJAnoEzQ9qWL"));
        
        // Địa chỉ không hợp lệ
        assert!(!provider.validate_address("invalid_address"));
        assert!(!provider.validate_address("1dkNKDGXR7FkH3mZAwxMrhxJAnoEzQ9qWL"));
    }
} 