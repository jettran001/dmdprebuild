//! Module quản lý thanh toán cho các gói đăng ký.
//!
//! Module này cung cấp các chức năng liên quan đến việc xử lý thanh toán cho các gói đăng ký,
//! bao gồm:
//! - Xử lý giao dịch thanh toán từ người dùng
//! - Kiểm tra trạng thái giao dịch trên blockchain
//! - Xác minh số tiền thanh toán và loại token phù hợp với gói đăng ký
//! - Xử lý lỗi liên quan đến blockchain
//! - Quản lý việc gia hạn đăng ký
//!
//! Module này tương tác với các module khác như user_subscription và staking, cũng như
//! các dịch vụ blockchain bên ngoài để đảm bảo quá trình thanh toán diễn ra trơn tru và an toàn.

use chrono::{DateTime, Utc};
use ethers::types::{Address, H256, TransactionReceipt, U256};
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use std::sync::Arc;
use tokio::sync::RwLock;
use tracing::{info, error, warn, debug};
use std::time::Duration;

use crate::blockchain::types::TokenInfo;
use crate::error::AppResult;
use crate::walletmanager::errors::WalletError;
use crate::walletmanager::WalletManagerApi;

use super::constants::{
    BLOCKCHAIN_TX_CONFIRMATION_BLOCKS, 
    BLOCKCHAIN_TX_RETRY_ATTEMPTS, 
    BLOCKCHAIN_TX_RETRY_DELAY_MS
};
use super::types::{PaymentToken, SubscriptionType, TransactionCheckResult};
use super::utils::{calculate_payment_amount, validate_transaction_hash, log_subscription_activity};

/// Thông tin về giao dịch thanh toán
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransactionInfo {
    /// ID giao dịch
    pub id: Uuid,
    /// Hash giao dịch blockchain
    pub tx_hash: String,
    /// Địa chỉ ví người gửi
    pub from_address: Address,
    /// Địa chỉ ví người nhận
    pub to_address: Address,
    /// Token dùng để thanh toán
    pub token: PaymentToken,
    /// Số lượng token
    pub amount: U256,
    /// Trạng thái giao dịch
    pub status: TransactionStatus,
    /// Thời điểm tạo giao dịch
    pub created_at: DateTime<Utc>,
    /// Thời điểm cập nhật giao dịch
    pub updated_at: DateTime<Utc>,
}

/// Trạng thái giao dịch
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TransactionStatus {
    /// Đang chờ xử lý
    Pending,
    /// Đã xác nhận
    Confirmed,
    /// Thất bại
    Failed,
    /// Đã hết hạn
    Expired,
}

impl Default for TransactionStatus {
    fn default() -> Self {
        Self::Pending
    }
}

/// Processor xử lý thanh toán
#[derive(Debug)]
pub struct PaymentProcessor {
    /// ID chuỗi blockchain đang sử dụng (BSC, Ethereum, v.v.)
    chain_id: u64,
    /// Địa chỉ ví nhận thanh toán
    payment_receiver: Address,
    /// Địa chỉ hợp đồng token DMD
    dmd_token_address: Address,
    /// Địa chỉ hợp đồng token USDC
    usdc_token_address: Address,
}

impl PaymentProcessor {
    /// Tạo processor mới
    pub fn new(
        chain_id: u64,
        payment_receiver: Address,
        dmd_token_address: Address,
        usdc_token_address: Address,
    ) -> Self {
        Self {
            chain_id,
            payment_receiver,
            dmd_token_address,
            usdc_token_address,
        }
    }
    
    /// Khởi tạo giao dịch thanh toán mới
    pub fn create_payment_transaction(
        &self,
        from_address: Address,
        payment_token: PaymentToken,
        amount: U256,
    ) -> TransactionInfo {
        let now = Utc::now();
        
        TransactionInfo {
            id: Uuid::new_v4(),
            tx_hash: String::new(), // Chưa có hash giao dịch
            from_address,
            to_address: self.payment_receiver,
            token: payment_token,
            amount,
            status: TransactionStatus::Pending,
            created_at: now,
            updated_at: now,
        }
    }
    
    /// Kiểm tra trạng thái giao dịch trên blockchain
    pub async fn check_transaction_status(
        &self,
        tx_hash: &str,
    ) -> AppResult<TransactionCheckResult> {
        // Thực hiện kiểm tra với số lần thử quy định
        for attempt in 0..BLOCKCHAIN_TX_RETRY_ATTEMPTS {
            match self.check_transaction_once(tx_hash).await {
                Ok(result) => {
                    // Nếu giao dịch đang pending và chưa phải lần thử cuối, tiếp tục đợi
                    if matches!(result, TransactionCheckResult::Pending) && 
                       attempt < BLOCKCHAIN_TX_RETRY_ATTEMPTS - 1 {
                        tokio::time::sleep(tokio::time::Duration::from_millis(BLOCKCHAIN_TX_RETRY_DELAY_MS)).await;
                        continue;
                    }
                    return Ok(result);
                },
                Err(e) if attempt < BLOCKCHAIN_TX_RETRY_ATTEMPTS - 1 => {
                    // Thử lại nếu có lỗi và chưa phải lần cuối
                    tokio::time::sleep(tokio::time::Duration::from_millis(BLOCKCHAIN_TX_RETRY_DELAY_MS)).await;
                },
                Err(e) => return Err(e.into()),
            }
        }
        
        // Nếu đã thử đủ số lần mà vẫn không có kết quả, trả về Timeout
        Ok(TransactionCheckResult::Timeout)
    }
    
    /// Kiểm tra giao dịch một lần
    async fn check_transaction_once(&self, tx_hash: &str) -> Result<TransactionCheckResult, WalletError> {
        // Kiểm tra tính hợp lệ của hash giao dịch
        if !validate_transaction_hash(tx_hash) {
            return Err(WalletError::InvalidTransactionHash);
        }

        // Kết nối đến blockchain và truy vấn thông tin giao dịch
        // TODO: Triển khai chi tiết kết nối blockchain và kiểm tra giao dịch thực tế
        
        // Giả lập các kết quả khác nhau dựa trên hash giao dịch (cho mục đích demo)
        if tx_hash.starts_with("0xc") {
            // Đã xác nhận
            let token_info = match self.get_token_info_from_tx(tx_hash).await {
                Ok(info) => info,
                Err(e) => {
                    error!("Không thể lấy thông tin token từ giao dịch {}: {:?}", tx_hash, e);
                    return Err(WalletError::BlockchainQueryError(format!("Không thể lấy thông tin token: {}", e)));
                }
            };
            
            let amount = match self.get_transaction_amount(tx_hash).await {
                Ok(amount) => amount,
                Err(e) => {
                    error!("Không thể lấy số lượng token từ giao dịch {}: {:?}", tx_hash, e);
                    return Err(WalletError::BlockchainQueryError(format!("Không thể lấy số lượng token: {}", e)));
                }
            };
            
            let plan = self.determine_subscription_plan(&amount, &token_info).map_err(|e| {
                error!("Không thể xác định gói đăng ký từ giao dịch {}: {:?}", tx_hash, e);
                WalletError::InvalidSubscriptionPlan
            })?;
            
            return Ok(TransactionCheckResult::Confirmed {
                token: token_info,
                amount,
                plan,
                tx_id: tx_hash.to_string(),
            });
        } else if tx_hash.starts_with("0xp") {
            // Đang chờ xử lý
            return Ok(TransactionCheckResult::Pending);
        } else if tx_hash.starts_with("0xf") {
            // Thất bại
            let reason = match self.get_transaction_failure_reason(tx_hash).await {
                Ok(reason) => reason,
                Err(e) => {
                    error!("Không thể lấy lý do thất bại từ giao dịch {}: {:?}", tx_hash, e);
                    "Không xác định được lý do thất bại".to_string()
                }
            };
            
            return Ok(TransactionCheckResult::Failed {
                reason,
            });
        } else if tx_hash.starts_with("0xe") {
            // Lỗi mạng
            return Err(WalletError::NetworkError("Không thể kết nối đến blockchain".to_string()));
        } else if tx_hash.starts_with("0xr") {
            // Lỗi rpc
            return Err(WalletError::RpcError("Lỗi từ node RPC".to_string()));
        }
        
        // Không tìm thấy
        Ok(TransactionCheckResult::Timeout)
    }
    
    /// Lấy thông tin token từ giao dịch
    async fn get_token_info_from_tx(&self, tx_hash: &str) -> Result<TokenInfo, WalletError> {
        // TODO: Triển khai chi tiết kết nối blockchain và lấy thông tin token
        // Đây là code mẫu để giả lập
        
        // Mô phỏng một số lỗi ngẫu nhiên để kiểm tra xử lý lỗi
        if tx_hash.ends_with("ff") {
            return Err(WalletError::BlockchainQueryError("Lỗi truy vấn thông tin token".to_string()));
        }
        
        Ok(TokenInfo {
            address: self.usdc_token_address,
            name: "USDC".to_string(),
            symbol: "USDC".to_string(),
            decimals: 6,
        })
    }
    
    /// Lấy số lượng token từ giao dịch
    async fn get_transaction_amount(&self, tx_hash: &str) -> Result<U256, WalletError> {
        // TODO: Triển khai chi tiết kết nối blockchain và lấy số lượng token
        // Đây là code mẫu để giả lập
        
        // Mô phỏng một số lỗi ngẫu nhiên để kiểm tra xử lý lỗi
        if tx_hash.ends_with("ee") {
            return Err(WalletError::BlockchainQueryError("Lỗi truy vấn số lượng token".to_string()));
        }
        
        Ok(U256::from(100))
    }
    
    /// Xác định gói đăng ký dựa trên số lượng token và loại token
    fn determine_subscription_plan(&self, amount: &U256, token_info: &TokenInfo) -> Result<SubscriptionType, WalletError> {
        // TODO: Triển khai logic xác định gói đăng ký dựa trên số lượng token
        // Đây là code mẫu để giả lập
        
        if amount >= &U256::from(1000) {
            Ok(SubscriptionType::VIP)
        } else if amount >= &U256::from(100) {
            Ok(SubscriptionType::Premium)
        } else if amount >= &U256::from(10) {
            Ok(SubscriptionType::Free)
        } else {
            Err(WalletError::InsufficientPaymentAmount)
        }
    }
    
    /// Lấy lý do thất bại của giao dịch
    async fn get_transaction_failure_reason(&self, tx_hash: &str) -> Result<String, WalletError> {
        // TODO: Triển khai chi tiết kết nối blockchain và lấy lý do thất bại
        // Đây là code mẫu để giả lập
        
        // Mô phỏng một số lỗi ngẫu nhiên để kiểm tra xử lý lỗi
        if tx_hash.ends_with("dd") {
            return Err(WalletError::BlockchainQueryError("Lỗi truy vấn lý do thất bại".to_string()));
        }
        
        if tx_hash.ends_with("1") {
            Ok("Số dư không đủ".to_string())
        } else if tx_hash.ends_with("2") {
            Ok("Gas price quá thấp".to_string())
        } else if tx_hash.ends_with("3") {
            Ok("Giao dịch bị hủy bởi người dùng".to_string())
        } else {
            Ok("Giao dịch bị từ chối bởi mạng".to_string())
        }
    }
    
    /// Xác nhận giao dịch đã được xử lý và cập nhật thông tin
    pub fn confirm_transaction(
        &self,
        transaction: &mut TransactionInfo,
        receipt: TransactionReceipt,
    ) -> AppResult<()> {
        let now = Utc::now();
        
        if receipt.status.unwrap_or_default().as_u64() == 1 {
            transaction.status = TransactionStatus::Confirmed;
        } else {
            transaction.status = TransactionStatus::Failed;
        }
        
        transaction.updated_at = now;
        
        Ok(())
    }
    
    /// Lấy địa chỉ hợp đồng token theo loại
    pub fn get_token_address(&self, token: PaymentToken) -> Address {
        match token {
            PaymentToken::DMD => self.dmd_token_address,
            PaymentToken::USDC => self.usdc_token_address,
        }
    }
}

/// Thông tin giao dịch thanh toán
#[derive(Debug, Clone)]
pub struct PaymentTransaction {
    /// ID người dùng
    pub user_id: String,
    /// Loại đăng ký
    pub subscription_type: SubscriptionType,
    /// Hash giao dịch
    pub tx_hash: H256,
    /// Địa chỉ ví thanh toán
    pub from_address: Address,
    /// Loại token thanh toán
    pub payment_token: PaymentToken,
    /// Số lượng token
    pub amount: U256,
    /// Thời gian bắt đầu giao dịch
    pub timestamp: DateTime<Utc>,
    /// Trạng thái giao dịch
    pub status: TransactionStatus,
    /// Số lần thử lại kiểm tra
    pub retry_count: u8,
}

/// Manager xử lý thanh toán đăng ký
pub struct PaymentManager {
    /// Wallet manager API
    wallet_manager: Arc<dyn WalletManagerApi>,
    /// Danh sách giao dịch đang chờ xử lý
    pending_transactions: RwLock<Vec<PaymentTransaction>>,
}

impl PaymentManager {
    /// Tạo một PaymentManager mới
    ///
    /// # Arguments
    /// * `wallet_manager` - API quản lý ví
    pub fn new(wallet_manager: Arc<dyn WalletManagerApi>) -> Self {
        Self {
            wallet_manager,
            pending_transactions: RwLock::new(Vec::new()),
        }
    }

    /// Xử lý giao dịch thanh toán mới
    ///
    /// # Arguments
    /// * `user_id` - ID người dùng
    /// * `subscription_type` - Loại đăng ký
    /// * `payment_token` - Loại token thanh toán
    /// * `tx_hash` - Hash giao dịch
    /// * `from_address` - Địa chỉ ví thanh toán
    pub async fn process_payment(
        &self,
        user_id: &str,
        subscription_type: SubscriptionType,
        payment_token: PaymentToken,
        tx_hash: &str,
        from_address: Address,
    ) -> Result<(), WalletError> {
        // Xác thực hash giao dịch
        if !validate_transaction_hash(tx_hash) {
            return Err(WalletError::InvalidTransactionHash);
        }
        
        // Chuyển đổi hash thành H256
        let hash_bytes = match hex::decode(&tx_hash[2..]) {
            Ok(bytes) => bytes,
            Err(_) => return Err(WalletError::InvalidTransactionHash),
        };
        
        let mut hash = [0u8; 32];
        if hash_bytes.len() == 32 {
            hash.copy_from_slice(&hash_bytes);
        } else {
            return Err(WalletError::InvalidTransactionHash);
        }
        
        let tx_hash = H256::from(hash);
        
        // Kiểm tra xem giao dịch đã tồn tại chưa
        {
            let transactions = self.pending_transactions.read().await;
            if transactions.iter().any(|tx| tx.tx_hash == tx_hash) {
                return Err(WalletError::TransactionAlreadyProcessed);
            }
        }
        
        // Tính toán số lượng token cần thiết
        let required_amount = calculate_payment_amount(subscription_type, payment_token);
        
        // Tạo thông tin giao dịch mới
        let transaction = PaymentTransaction {
            user_id: user_id.to_string(),
            subscription_type,
            tx_hash,
            from_address,
            payment_token,
            amount: required_amount,
            timestamp: Utc::now(),
            status: TransactionStatus::Pending,
            retry_count: 0,
        };
        
        // Lưu giao dịch vào danh sách đang chờ xử lý
        {
            let mut transactions = self.pending_transactions.write().await;
            transactions.push(transaction);
        }
        
        // Ghi log hoạt động
        log_subscription_activity(
            user_id,
            format!("Đã nhận yêu cầu thanh toán: {:?}", tx_hash),
        );
        
        Ok(())
    }

    /// Kiểm tra tất cả các giao dịch đang chờ xử lý
    pub async fn check_pending_transactions(&self) -> Result<(), WalletError> {
        // Lấy danh sách giao dịch đang chờ xử lý
        let transactions = self.pending_transactions.read().await.clone();
        
        for tx in transactions {
            // Bỏ qua các giao dịch đã xác nhận hoặc thất bại
            if tx.status != TransactionStatus::Pending {
                continue;
            }
            
            match self.check_transaction_status(&tx).await {
                Ok(new_status) => {
                    if new_status != tx.status {
                        let new_retry_count = tx.retry_count + 1;
                        self.update_transaction_status(&tx.tx_hash, new_status, new_retry_count).await;
                        
                        // Ghi log
                        info!(
                            "Cập nhật trạng thái giao dịch {} cho user {}: {:?} -> {:?}",
                            tx.tx_hash, tx.user_id, tx.status, new_status
                        );
                        
                        // Ghi log hoạt động
                        log_subscription_activity(
                            &tx.user_id,
                            format!("Cập nhật trạng thái giao dịch {:?}: {:?}", tx.tx_hash, new_status),
                        );
                    }
                },
                Err(e) => {
                    error!("Lỗi khi kiểm tra giao dịch {}: {:?}", tx.tx_hash, e);
                }
            }
        }
        
        Ok(())
    }

    /// Kiểm tra trạng thái của một giao dịch cụ thể
    async fn check_transaction_status(&self, tx: &PaymentTransaction) -> Result<TransactionStatus, WalletError> {
        // Thực hiện kiểm tra với cơ chế thử lại
        let mut retries = 0;
        let max_retries = 3;
        let mut last_error = None;

        while retries < max_retries {
            match self.check_transaction_once(tx).await {
                Ok(status) => return Ok(status),
                Err(e) => {
                    // Ghi log lỗi
                    warn!(
                        "Lần thử {}/{}: Lỗi khi kiểm tra giao dịch {}: {:?}",
                        retries + 1, max_retries, tx.tx_hash, e
                    );
                    
                    // Lưu lỗi mới nhất
                    last_error = Some(e);
                    
                    // Đợi một chút trước khi thử lại
                    tokio::time::sleep(Duration::from_secs(2 * (retries + 1) as u64)).await;
                    
                    retries += 1;
                }
            }
        }

        // Trả về lỗi cuối cùng sau khi đã thử tối đa số lần
        Err(last_error.unwrap_or(WalletError::BlockchainQueryError(
            "Đã vượt quá số lần thử tối đa khi kiểm tra trạng thái giao dịch".to_string()
        )))
    }

    /// Thực hiện một lần kiểm tra trạng thái giao dịch
    async fn check_transaction_once(&self, tx: &PaymentTransaction) -> Result<TransactionStatus, WalletError> {
        // Ghi log bắt đầu kiểm tra
        debug!("Bắt đầu kiểm tra trạng thái giao dịch: {:?}", tx.tx_hash);
        
        // Kiểm tra tham số đầu vào
        if tx.user_id.is_empty() {
            error!("user_id không hợp lệ khi kiểm tra giao dịch: {:?}", tx.tx_hash);
            return Err(WalletError::InvalidParameter("user_id không được để trống".to_string()));
        }
        
        // Lấy hash giao dịch dưới dạng chuỗi để demo
        let tx_hash_str = format!("{:?}", tx.tx_hash);
        
        // Kiểm tra tính hợp lệ của hash giao dịch
        if tx_hash_str.len() < 10 || !tx_hash_str.starts_with("0x") {
            error!("Hash giao dịch không hợp lệ: {}", tx_hash_str);
            return Err(WalletError::InvalidTransactionHash);
        }
        
        // Kiểm tra thời gian chờ xử lý, nếu quá lâu thì đánh dấu là hết hạn
        let now = Utc::now();
        let transaction_age = now.signed_duration_since(tx.timestamp);
        if transaction_age > chrono::Duration::hours(24) {
            warn!("Giao dịch {} đã quá thời gian chờ xử lý (24 giờ)", tx_hash_str);
            return Ok(TransactionStatus::Expired);
        }
        
        // Thử kết nối với blockchain để lấy thông tin giao dịch
        let transaction_result = match self.wallet_manager.get_transaction(&tx_hash_str).await {
            Ok(result) => result,
            Err(e) => {
                error!("Lỗi khi lấy thông tin giao dịch từ blockchain: {}: {:?}", tx_hash_str, e);
                
                // Phân loại lỗi để xử lý phù hợp
                match e {
                    WalletError::NetworkError(ref msg) => {
                        error!("Lỗi mạng khi lấy thông tin giao dịch {}: {}", tx_hash_str, msg);
                        // Đối với lỗi mạng, giữ trạng thái hiện tại và thử lại sau
                        return Ok(tx.status);
                    },
                    WalletError::TimeoutError(ref msg) => {
                        warn!("Timeout khi lấy thông tin giao dịch {}: {}", tx_hash_str, msg);
                        // Đối với timeout, giữ trạng thái hiện tại và thử lại sau
                        return Ok(tx.status);
                    },
                    WalletError::RpcError(ref msg) => {
                        error!("Lỗi RPC khi lấy thông tin giao dịch {}: {}", tx_hash_str, msg);
                        // Đối với lỗi RPC, giữ trạng thái hiện tại và thử lại sau
                        return Ok(tx.status);
                    },
                    _ => {
                        // Trả về lỗi cho các trường hợp khác để xử lý ở tầng cao hơn
                        return Err(e);
                    }
                }
            }
        };
        
        // Kiểm tra xem giao dịch đã được xác nhận chưa
        if let Some(receipt) = transaction_result.receipt {
            // Kiểm tra số block xác nhận
            let confirmations = match transaction_result.confirmations {
                Some(count) => count,
                None => {
                    warn!("Không tìm thấy thông tin xác nhận cho giao dịch {}", tx_hash_str);
                    return Ok(TransactionStatus::Pending);
                }
            };
            
            // Kiểm tra xem đã đủ số block xác nhận chưa
            if confirmations < BLOCKCHAIN_TX_CONFIRMATION_BLOCKS {
                debug!(
                    "Giao dịch {} có {} xác nhận, cần tối thiểu {}",
                    tx_hash_str, confirmations, BLOCKCHAIN_TX_CONFIRMATION_BLOCKS
                );
                return Ok(TransactionStatus::Pending);
            }
            
            // Kiểm tra xem giao dịch có thành công không
            if receipt.status.unwrap_or_default().as_u64() == 1 {
                // Xác minh số tiền thanh toán
                match self.verify_payment_amount(tx).await {
                    Ok(true) => {
                        info!("Giao dịch {} thành công và số tiền thanh toán đã được xác minh", tx_hash_str);
                        return Ok(TransactionStatus::Confirmed);
                    },
                    Ok(false) => {
                        warn!("Giao dịch {} thành công nhưng số tiền thanh toán không đủ", tx_hash_str);
                        return Ok(TransactionStatus::Failed);
                    },
                    Err(e) => {
                        match e {
                            WalletError::NetworkError(ref msg) => {
                                warn!("Lỗi mạng khi xác minh số tiền cho giao dịch {}: {}", tx_hash_str, msg);
                                // Với lỗi mạng, giữ trạng thái hiện tại và thử lại sau
                                return Ok(tx.status);
                            },
                            WalletError::TimeoutError(ref msg) => {
                                warn!("Timeout khi xác minh số tiền cho giao dịch {}: {}", tx_hash_str, msg);
                                // Với timeout, giữ trạng thái hiện tại và thử lại sau
                                return Ok(tx.status);
                            },
                            WalletError::BlockchainQueryError(ref msg) => {
                                // Ghi log chi tiết về lỗi truy vấn blockchain
                                error!("Lỗi truy vấn blockchain khi xác minh số tiền cho giao dịch {} từ user {}: {}", 
                                       tx_hash_str, tx.user_id, msg);
                                
                                // Đối với lỗi truy vấn blockchain, giữ trạng thái hiện tại nếu số lần thử ít
                                if tx.retry_count < 5 {
                                    return Ok(TransactionStatus::Pending);
                                } else {
                                    // Nếu đã thử nhiều lần, đánh dấu là lỗi
                                    warn!("Đã vượt quá số lần thử xác minh số tiền cho giao dịch {}", tx_hash_str);
                                    return Ok(TransactionStatus::Failed);
                                }
                            },
                            _ => {
                                // Ghi log chi tiết về lỗi không xác định
                                error!("Lỗi không xác định khi xác minh số tiền cho giao dịch {} từ user {}: {:?}", 
                                       tx_hash_str, tx.user_id, e);
                                
                                // Các lỗi khác, đánh dấu là đang chờ xử lý và thử lại sau
                                return Ok(TransactionStatus::Pending);
                            }
                        }
                    }
                }
            } else {
                // Giao dịch thất bại trên blockchain
                error!("Giao dịch {} thất bại trên blockchain", tx_hash_str);
                
                // Thử lấy lý do thất bại
                let failure_reason = match self.wallet_manager.get_transaction_failure_reason(&tx_hash_str).await {
                    Ok(reason) => reason,
                    Err(e) => {
                        error!("Không thể lấy lý do thất bại cho giao dịch {}: {:?}", tx_hash_str, e);
                        "Không xác định được lý do thất bại".to_string()
                    }
                };
                
                // Ghi log chi tiết về lý do thất bại
                error!(
                    "Giao dịch thất bại cho user {}: {} - Lý do: {}",
                    tx.user_id, tx_hash_str, failure_reason
                );
                
                return Ok(TransactionStatus::Failed);
            }
        } else if tx_hash_str.starts_with("0xp") {
            // Vẫn đang chờ
            debug!("Giao dịch {} vẫn đang chờ xử lý trên blockchain", tx_hash_str);
            return Ok(TransactionStatus::Pending);
        } else if tx_hash_str.starts_with("0xf") {
            // Thất bại
            // Thử lấy lý do thất bại từ blockchain
            let failure_reason = match self.wallet_manager.get_transaction_failure_reason(&tx_hash_str).await {
                Ok(reason) => reason,
                Err(e) => {
                    error!("Không thể lấy lý do thất bại cho giao dịch {}: {:?}", tx_hash_str, e);
                    
                    match e {
                        WalletError::NetworkError(ref msg) => {
                            warn!("Lỗi mạng khi lấy lý do thất bại cho giao dịch {}: {}", tx_hash_str, msg);
                            // Với lỗi mạng, thử lại sau
                            return Ok(tx.status);
                        },
                        _ => "Không xác định được lý do thất bại".to_string()
                    }
                }
            };
            
            // Ghi log chi tiết về lý do thất bại
            error!(
                "Giao dịch thất bại cho user {}: {} - Lý do: {}",
                tx.user_id, tx_hash_str, failure_reason
            );
            
            return Ok(TransactionStatus::Failed);
        } else if tx.retry_count > 10 {
            // Quá nhiều lần thử, coi như hết hạn
            warn!("Giao dịch {} đã vượt quá số lần thử lại ({}), đánh dấu là hết hạn", tx_hash_str, tx.retry_count);
            
            // Ghi log chi tiết về việc giao dịch hết hạn
            error!(
                "Giao dịch của user {} hết hạn do vượt quá số lần thử: {} - Loại đăng ký: {:?}",
                tx.user_id, tx_hash_str, tx.subscription_type
            );
            
            return Ok(TransactionStatus::Expired);
        } else {
            // Không tìm thấy thông tin giao dịch
            warn!("Không tìm thấy thông tin giao dịch {} trên blockchain", tx_hash_str);
            
            // Nếu số lần thử ít, giữ nguyên trạng thái
            if tx.retry_count < 5 {
                return Ok(TransactionStatus::Pending);
            } else {
                // Quá nhiều lần thử, coi như hết hạn
                warn!("Đã thử {} lần nhưng không tìm thấy giao dịch {}", tx.retry_count, tx_hash_str);
                return Ok(TransactionStatus::Expired);
            }
        }
        
        // Không có thay đổi
        debug!("Không có thay đổi trạng thái cho giao dịch {}", tx_hash_str);
        Ok(tx.status)
    }
    
    /// Xác minh số tiền thanh toán từ blockchain
    async fn verify_payment_amount(&self, tx: &PaymentTransaction) -> Result<bool, WalletError> {
        let tx_hash_str = format!("{:?}", tx.tx_hash);
        debug!("Bắt đầu xác minh số tiền thanh toán cho giao dịch: {}", tx_hash_str);
        
        // Kiểm tra tham số đầu vào
        if tx.user_id.is_empty() {
            error!("user_id không hợp lệ khi xác minh số tiền: {:?}", tx.tx_hash);
            return Err(WalletError::InvalidParameter("user_id không được để trống".to_string()));
        }
        
        if tx.amount.is_zero() {
            error!("Số tiền dự kiến không hợp lệ: {:?}", tx.tx_hash);
            return Err(WalletError::InvalidParameter("Số tiền thanh toán dự kiến không hợp lệ".to_string()));
        }
        
        // Kiểm tra thời gian tồn tại của giao dịch
        let transaction_age = Utc::now().signed_duration_since(tx.timestamp);
        if transaction_age > chrono::Duration::hours(72) {
            warn!("Giao dịch {} quá cũ (> 72 giờ), có thể gặp vấn đề khi xác minh", tx_hash_str);
            
            // Ghi log chi tiết về việc giao dịch quá cũ
            warn!(
                "Giao dịch của user {} quá cũ (> 72 giờ): {} - Thời gian: {}",
                tx.user_id, tx_hash_str, tx.timestamp
            );
        }
        
        // Kiểm tra và lấy số tiền thực tế từ blockchain
        let actual_amount = match self.wallet_manager.get_transaction_amount(&tx_hash_str).await {
            Ok(amount) => amount,
            Err(e) => {
                error!("Lỗi khi lấy số tiền giao dịch {} từ blockchain: {:?}", tx_hash_str, e);
                
                match e {
                    WalletError::NetworkError(ref msg) => {
                        error!("Lỗi mạng khi lấy số tiền giao dịch {}: {}", tx_hash_str, msg);
                        return Err(WalletError::NetworkError(format!(
                            "Lỗi mạng khi lấy số tiền giao dịch: {}", msg
                        )));
                    },
                    WalletError::TimeoutError(ref msg) => {
                        warn!("Timeout khi lấy số tiền giao dịch {}: {}", tx_hash_str, msg);
                        return Err(WalletError::TimeoutError(format!(
                            "Timeout khi lấy số tiền giao dịch: {}", msg
                        )));
                    },
                    WalletError::BlockchainQueryError(ref msg) => {
                        error!("Lỗi truy vấn blockchain khi lấy số tiền giao dịch {}: {}", tx_hash_str, msg);
                        return Err(WalletError::BlockchainQueryError(format!(
                            "Lỗi truy vấn blockchain khi lấy số tiền: {}", msg
                        )));
                    },
                    WalletError::RpcError(ref msg) => {
                        error!("Lỗi RPC khi lấy số tiền giao dịch {}: {}", tx_hash_str, msg);
                        return Err(WalletError::RpcError(format!(
                            "Lỗi RPC khi lấy số tiền giao dịch: {}", msg
                        )));
                    },
                    _ => return Err(e),
                }
            }
        };
        
        // So sánh số tiền thực tế với số tiền dự kiến
        if actual_amount < tx.amount {
            warn!(
                "Số tiền thanh toán không đủ cho giao dịch {}: Yêu cầu {} nhưng chỉ nhận được {}",
                tx.tx_hash, tx.amount, actual_amount
            );
            
            // Ghi log chi tiết về số tiền không đủ
            error!(
                "Chi tiết thanh toán không đủ - User: {}, Subscription: {:?}, Token: {:?}, Expected: {}, Received: {}",
                tx.user_id, tx.subscription_type, tx.payment_token, tx.amount, actual_amount
            );
            
            // Kiểm tra xem số tiền có đủ để nâng cấp lên gói thấp hơn không
            if tx.subscription_type == SubscriptionType::Vip && 
               actual_amount >= calculate_payment_amount(SubscriptionType::Premium, tx.payment_token) {
                warn!(
                    "Số tiền đủ để nâng cấp lên gói Premium cho user {} thay vì VIP: {} - Nhận: {}",
                    tx.user_id, tx.amount, actual_amount
                );
                
                // TODO: Xử lý logic nâng cấp lên gói thấp hơn dựa trên số tiền thực tế
                // Trả về true nhưng xử lý ở lớp cao hơn
                info!(
                    "Chấp nhận thanh toán với số tiền thấp hơn, điều chỉnh gói đăng ký cho user {}",
                    tx.user_id
                );
                return Ok(true);
            }
            
            return Ok(false);
        }
        
        // Kiểm tra loại token thanh toán
        let token_info = match self.wallet_manager.get_token_info_from_tx(&tx_hash_str).await {
            Ok(info) => info,
            Err(e) => {
                error!("Lỗi khi lấy thông tin token từ giao dịch {}: {:?}", tx_hash_str, e);
                
                match e {
                    WalletError::NetworkError(ref msg) => {
                        error!("Lỗi mạng khi lấy thông tin token từ giao dịch {}: {}", tx_hash_str, msg);
                        return Err(WalletError::NetworkError(format!(
                            "Lỗi mạng khi lấy thông tin token: {}", msg
                        )));
                    },
                    WalletError::TimeoutError(ref msg) => {
                        warn!("Timeout khi lấy thông tin token từ giao dịch {}: {}", tx_hash_str, msg);
                        return Err(WalletError::TimeoutError(format!(
                            "Timeout khi lấy thông tin token: {}", msg
                        )));
                    },
                    WalletError::BlockchainQueryError(ref msg) => {
                        error!("Lỗi truy vấn blockchain khi lấy thông tin token từ giao dịch {}: {}", tx_hash_str, msg);
                        return Err(WalletError::BlockchainQueryError(format!(
                            "Lỗi truy vấn blockchain khi lấy thông tin token: {}", msg
                        )));
                    },
                    _ => return Err(e),
                }
            }
        };
        
        // Kiểm tra xem đúng loại token không
        let expected_token_address = self.wallet_manager.get_token_address(tx.payment_token);
        if token_info.address != expected_token_address {
            error!(
                "Loại token không đúng cho giao dịch {}: Expected {} nhưng nhận được {}",
                tx_hash_str, expected_token_address, token_info.address
            );
            
            // Ghi log chi tiết về token không đúng
            error!(
                "Chi tiết token không đúng - User: {}, Expected: {}, Received: {}, Symbol: {}",
                tx.user_id, expected_token_address, token_info.address, token_info.symbol
            );
            
            return Ok(false);
        }
        
        // Số tiền đủ
        debug!("Xác minh thành công số tiền thanh toán cho giao dịch {}", tx_hash_str);
        
        // Ghi log thành công
        info!(
            "Xác minh thành công thanh toán - User: {}, Hash: {}, Subscription: {:?}, Amount: {}",
            tx.user_id, tx_hash_str, tx.subscription_type, tx.amount
        );
        
        Ok(true)
    }

    /// Cập nhật trạng thái giao dịch
    async fn update_transaction_status(
        &self, 
        tx_hash: &H256, 
        new_status: TransactionStatus,
        retry_count: u8,
    ) {
        let mut transactions = self.pending_transactions.write().await;
        
        if let Some(tx) = transactions.iter_mut().find(|t| t.tx_hash == *tx_hash) {
            tx.status = new_status;
            tx.retry_count = retry_count;
        }
    }

    /// Lấy thông tin giao dịch theo hash
    pub async fn get_transaction(&self, tx_hash: &H256) -> Option<PaymentTransaction> {
        let transactions = self.pending_transactions.read().await;
        transactions.iter().find(|tx| tx.tx_hash == *tx_hash).cloned()
    }

    /// Kiểm tra xem giao dịch đã được xác nhận chưa
    pub async fn is_transaction_confirmed(&self, user_id: &str, tx_hash: &H256) -> bool {
        let transactions = self.pending_transactions.read().await;
        
        transactions
            .iter()
            .any(|tx| tx.user_id == user_id && tx.tx_hash == *tx_hash && tx.status == TransactionStatus::Confirmed)
    }
} 