//! Test cases cho free_user module và các module khác.

mod auth_tests;
mod limits_tests;
mod records_tests;
mod cache_tests;